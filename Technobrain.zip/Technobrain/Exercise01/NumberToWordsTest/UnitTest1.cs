using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace NumberToWordsTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
