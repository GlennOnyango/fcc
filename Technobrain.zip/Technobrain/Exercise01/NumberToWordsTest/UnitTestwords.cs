﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exercise01;
using System;

namespace NumberToWordsTest
{
    [TestClass]
    public class UnitTest1Words
    {
        [TestMethod]
        public void TestNumerictoWordsConvertion()
        {
            int[] numbers = {1000,543545,324324,90,1};

            foreach (int n in numbers) 
            {

                bool result = false;
                string word = Class1.NumberConvertor(n);

                if (word is string) {

                    result = true;
                    Assert.IsTrue(result,
                      String.Format("Expected for '{0}': true; Actual: {1}",
                                    word, result));
                }

            }
        }
    }
}
