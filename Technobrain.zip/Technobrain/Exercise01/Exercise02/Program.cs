﻿using System;
using Exercise01;
namespace Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            bool shut = true;
            int number = 0; 
            do 
            {

                Console.WriteLine("Please Enter any number:\n");

                string intor = Console.ReadLine();
                if (intor == "y")
                {

                    Console.WriteLine("Shutting down application");
                    shut = false;
                }
                else if (Int32.TryParse(intor, out number))
                {

                    Console.WriteLine($"The number -> {Class1.NumberConvertor(number)}");
                    shut = true;

                }
                else
                {
                    Console.WriteLine("Invalid Entry");
                    Console.WriteLine("Try again or close by pressing [y]");
                    shut = true;

                }
                } while (shut);

            
            
        }
    }
}
