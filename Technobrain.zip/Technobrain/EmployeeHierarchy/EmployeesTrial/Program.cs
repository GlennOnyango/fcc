﻿using System;
using System.IO;
using EmployeesCase;
namespace EmployeesTrial
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            string path = @"D:\Employee.csv";

            Employees emp = new Employees(path);
            emp.SalaryBudget("Employee2");

        }
    }
}
