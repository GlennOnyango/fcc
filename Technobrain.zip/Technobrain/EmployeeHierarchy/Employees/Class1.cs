﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace EmployeesCase
{
    

    public class Employees 
    {
        private int default_salary = 0;

        private List<string[]> records = new List<string[]>();

        private List<string> colEmployee = new List<string>();

        private List<string> ManagerEmployee = new List<string>();
        private List<string> EmployeeSalary = new List<string>();
        private List<int> EmployeeSalaryAfterCheck = new List<int>();
        private int ceoCount = 0;
        private int count = 0;

        public Employees(string input) 
        {

            string path = input;

            var reader = new StreamReader(File.OpenRead(path));

            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] values = line.Split(',');

                colEmployee.Add(values[0]);
                ManagerEmployee.Add(values[1]);
                EmployeeSalary.Add(values[2]);


                records.Add(new string[] { values[0], values[1], values[2] });
            }


            //check Salary for non integers
            foreach (string salary in EmployeeSalary)
            {
                int employeeSalary = 0;


                if (int.TryParse(salary, out employeeSalary))
                {
                    EmployeeSalaryAfterCheck.Add(employeeSalary);
                }
                else
                {
                    Console.WriteLine("Not all salaries are integers");
                    Environment.Exit(0);
                }
            }



            //Avoid dupicate employees which can cause same manager for same person
            if (colEmployee.Count != colEmployee.Distinct().Count())
            {
                // Duplicates exist
                Console.WriteLine("Duplicate employees risk of having different managers or salary count issue");
            }

            //One ceo for the company check
            foreach (string s in ManagerEmployee)
            {
                if (count <= 2)
                {

                    if (String.IsNullOrEmpty(s))
                    {
                        count++;
                    }
                }
                else
                {

                    Console.WriteLine("More than one CEO can not be accepted ->" + count);
                    Environment.Exit(0);
                }

            }

            //PreventCircular

            foreach (string[] recs in records)
            {

                PreventCircular(records, recs[0], recs[1]);

            }

        }


        private void PreventCircular(List<string[]> records, string value1, string value2)
        {

            foreach (string[] r in records)
            {
                if (r[1] == value1 && r[0] == value2)
                {

                    Console.WriteLine("Circular references detected");
                    Environment.Exit(0);
                }
            }

        }

        private List<string> show_below(string employee)
        {
            List<string> under = new List<string>();
            List<string> underscreen = new List<string>();
            foreach (string[] reco in records)
            {

                if (reco[1] == employee)
                {

                    under.Add(reco[0]);
                    Console.WriteLine(reco[1]);

                }

            }

            if (under.Count > 0)
            {


                foreach (string u in under)
                {


                    Console.WriteLine("under ->:" + u);
                    underscreen.Add(u);
                    show_below(u);
                }



            }
            underscreen.Add(employee);
            return underscreen;

        }


        private long getSalary(List<string> emp)

        {
            long net = 0;
            foreach (string salr in emp)
            {

                foreach (string[] sal in records)
                {

                    if (sal[0] == salr)
                    {
                        Console.WriteLine($"The ind salary of {sal[0]} is {sal[2]}");
                        net += int.Parse(sal[2]);
                        Console.WriteLine(net);

                    }

                }
            }

            return net;
        }

        public void SalaryBudget(string employee) {

            Console.WriteLine("The net salary is ->: " + getSalary(show_below(employee)));

        }

    }



}
